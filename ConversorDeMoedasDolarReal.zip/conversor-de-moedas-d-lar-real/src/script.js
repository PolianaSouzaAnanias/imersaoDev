//Solicita valor ao usuário.
var valorRealTexto = prompt("Digite um valor em R$ (reais) que deseja converter: ")

var valorRealNumero = parseFloat(valorRealTexto)

var valorDolar = valorRealNumero*5.50

var valorDolarDecimal = valorDolar.toFixed(2)
//Mostra na tela o valor em dólar.
alert("Valor em U$: "+valorDolarDecimal)
