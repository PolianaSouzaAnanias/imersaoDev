var pokemon = prompt("Quem é esse pokemon? Escolha uma opção: \n1: Bulbasaur, \n2: Sharmander, \n3: Squirtle, \n4: Pikachu")

if (pokemon == 3){
  var resultado = "Squirtle! Você acertou!"
  document.write ("<h2>" +  "Squirtle" + "</h2>") 
}  else {
  document.write ("<h2>" + "Opção errada! Tente outra vez" + "</h2>")
}
