 alert("Você foi convid@ a adivinhar o número secreto. Digite OK ou aperte o botão ENTER para continuar. Boa Sorte!")
var numeroSecreto = parseInt(Math.random() * 10)
var tentativas = 3

while (tentativas > 0) {
   
 var chute = parseInt(prompt("Digite um número de 1 a 10:"))
   if (numeroSecreto == chute) {
   document.write ("<h2>" + "Parabéns! Você acertou!" + "</h2>")
     break
   } else if (chute > numeroSecreto) {
    alert("Dica: O número de moedas é menor!")
  } else if (chute < numeroSecreto) {
    alert("Dica: O número de moedas é maior!")
    tentativas = tentativas -1
  } else {
    alert("Não fio dessa vez. A quantidade de moedas foi: ."  + numeroSecreto)
    tentativas = tentativas -1
} 
}
