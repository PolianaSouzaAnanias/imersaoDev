document.getElementsByTagName("h1")[0].style.fontSize = "4vw";

var nomeusuario = prompt("Qual o seu nome?")
var idadeusuario = prompt("Qual a sua idade?")

alert(nomeusuario+idadeusuario)