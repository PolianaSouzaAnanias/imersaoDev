//Solicita valor ao usuário.
var comprimento = prompt("Digite o comprimeiro do aquário: ")
var largura = prompt("Digite a largura: ")
var altura = prompt("Digite a altura: ")

//Transformar dados de texto em números.
var valorComprimento = parseFloat(comprimento)
var valorLargura = parseFloat(largura)
var valorAltura = parseFloat(altura)

var volume = (valorComprimento*valorLargura*valorAltura)/1000

var volumeDecimal = volume.toFixed(2)

//Mostra na tela o valor em dólar.
document.write("<h2>" + "Volume: "+volumeDecimal + "L" + "</2>")

